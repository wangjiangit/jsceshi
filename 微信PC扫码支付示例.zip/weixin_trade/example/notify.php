<?php
ini_set('date.timezone','Asia/Shanghai');
error_reporting(E_ERROR);

require_once "../lib/WxPay.Api.php";
require_once '../lib/WxPay.Notify.php';
require_once 'log.php';

//初始化日志
$logHandler= new CLogFileHandler("../logs/".date('Y-m-d').'.log');
$log = Log::Init($logHandler, 15);

class PayNotifyCallBack extends WxPayNotify
{
	//查询订单
	//public function Queryorder($transaction_id)
	public function Queryorder($out_trade_id)
	{
		$input = new WxPayOrderQuery();
		//$input->SetTransaction_id($transaction_id);
		 $input->SetOut_trade_no($out_trade_id);
		$result = WxPayApi::orderQuery($input);
		Log::DEBUG("query:" . json_encode($result));
		if(array_key_exists("return_code", $result)
			&& array_key_exists("result_code", $result)
			&& $result["return_code"] == "SUCCESS"
			&& $result["result_code"] == "SUCCESS")
		{
			return true;
		}
		return false;
	}
	
	//重写回调处理函数
	public function NotifyProcess($data, &$msg)
	{
		Log::DEBUG("微信异步通知数据:" . json_encode($data));
		$notfiyOutput = array();
		
		if(!array_key_exists("out_trade_no", $data)){
			$msg = "输入参数不正确";
			Log::ERROR($msg,',微信异步通知中无out_trade_no参数');
			return false;
		}
		//查询订单，判断订单真实性
		if(!$this->Queryorder($data["out_trade_no"])){
			$msg = "订单查询失败";
			Log::ERROR($msg.',商户订单号：'.$data['out_trade_no']);
			return false;
		}

		//业务逻辑 处理

		try{
			$pdo=new \PDO(WxPayConfig::DB_DSN,WxPayConfig::DB_USERNAME,WxPayConfig::DB_PASSWORD);
			$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
			$sqlString="SELECT `id`, `out_trade_no`,`total_amount` FROM orders WHERE out_trade_no=:out_trade_no";
			$prepare=$pdo->prepare($sqlString);
			$prepare->bindParam(':out_trade_no',$data["out_trade_no"]);
			$prepare->execute();
			$row=$prepare->fetch(PDO::FETCH_ASSOC);

			//如果为空数组
			if(!$row){
				Log::ERROR('异步通知：与商户订单号不一致，商户订单号:'.$data['out_trade_no']);
				return false;
			}

			if(!empty($row)){
				if( $row['total_amount']!=$data['total_fee']){
					Log::ERROR('异步通知：与商户订单总额不一致，商户订单号:'.$data['total_amount']);
					return false;
				}
			}

			$sqlString="UPDATE orders SET trade_status=3 WHERE out_trade_no=:out_trade_no LIMIT 1";
			$prepare=$pdo->prepare($sqlString);
			$prepare->bindParam(':out_trade_no',$data["out_trade_no"]);
			$result=$prepare->execute();
			//Log::INFO('SQL 语句:'.$sqlString.'PDO执行结果'.$result);
			//如果执行失败
			if(!$result){
				Log::ERROR('异步通知更新失败,商户订单号:'.$data['out_trade_no']);
				return false;
			}


		}catch(PDOException $e){
			Log::ERROR('数据库异常信息00002'.$e->getMessage());
			return false;
		}

		return true;
	}
}

Log::DEBUG("begin notify");
$notify = new PayNotifyCallBack();
$notify->Handle(false);
