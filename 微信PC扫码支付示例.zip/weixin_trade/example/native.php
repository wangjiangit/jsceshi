<?php
ini_set('date.timezone','Asia/Shanghai');
//error_reporting(E_ERROR);

require_once "../lib/WxPay.Api.php";
require_once "WxPay.NativePay.php";
require_once 'log.php';

$notify = new NativePay();

//采用模式二
/**
 * 流程：
 * 1、调用统一下单，取得code_url，生成二维码
 * 2、用户扫描二维码，进行支付
 * 3、支付完成之后，微信服务器会通知支付成功
 * 4、在支付成功通知中需要查单确认是否真正支付成功（见：notify.php）
 */

// 业务逻辑----------------------START------------------------------
//公共函数
function toJson($arr){
	header('Content-type: application/json');
	echo json_encode($arr);
	exit;
}
//商户订单号，商户网站订单系统中唯一订单号，必填

$out_trade_no=strtr(date('YmdHis').microtime(true),'.','-');  //订单号服务器端生成
//商品描述，必填
// $subject = trim($_POST['WIDsubject']);
$subject='有道云团队版';
//付款金额，必填
//$total_amount = trim($_POST['WIDtotal_amount']);
$duration=intval($_POST['duration']);
$durationAmount=[1=>498,2=>898,3=>1298];
if(!array_key_exists($duration,$durationAmount)){
	toJson(['errcode'=>1,'errmsg'=>'购买年限不符合']);
}

$total_amount=$durationAmount[$duration];

//姓名
$name=htmlspecialchars(trim($_POST['name']));
//手机号码
$iphoneNo=$_POST['iphone_no'];
if(!preg_match("/^1[34578]{1}\d{9}$/",$iphoneNo)){
	toJson(['errcode'=>1,'errmsg'=>'请输入正确的手机号']);
}
$iphoneNo=htmlspecialchars(trim($iphoneNo));
//邮箱
$email=$_POST['email'];
if(!preg_match("/^[a-z]?([a-z0-9]*[-_]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[\.][a-z]{2,3}([\.][a-z]{2})?$/i",$email)){
	toJson(['errcode'=>1,'errmsg'=>'请输入正确的邮箱']);
}

$data=[
	'name'=>$name,
	'iphone_no'=>$iphoneNo,
	'email'=>$email,
	'product_no'=>1,
	'duration'=>$duration,
	'out_trade_no'=>$out_trade_no,
	'total_amount'=>$total_amount*100,
	'trade_status'=>1,
	'seller_id'=>WxPayConfig::MCHID, //微信支付的商户号mch_id
	'pay_type'=>2,
	'create_time'=>time(),
	'update_time'=>time()

];
try{
	$pdo=new \PDO(WxPayConfig::DB_DSN,WxPayConfig::DB_USERNAME,WxPayConfig::DB_PASSWORD);
	$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	$sqlString="INSERT INTO orders(`name`,`iphone_no`,`email`,`product_no`,`duration`,`out_trade_no`,`total_amount`,`trade_status`,`seller_id`,`pay_type`,`create_time`,`update_time`)
    VALUES(:name,:iphone_no,:email,:product_no,:duration,:out_trade_no,:total_amount,:trade_status,:seller_id,:pay_type,:create_time,:update_time)";
	$prepare=$pdo->prepare($sqlString);
	$prepare->bindParam(':name',$data['name']);
	$prepare->bindParam(':iphone_no',$data['iphone_no']);
	$prepare->bindParam(':email',$data['email']);
	$prepare->bindParam(':product_no',$data['product_no'],PDO::PARAM_INT);
	$prepare->bindParam(':duration',$data['duration'],PDO::PARAM_INT);
	$prepare->bindParam(':out_trade_no',$data['out_trade_no']);
	$prepare->bindParam(':total_amount',$data['total_amount'],PDO::PARAM_INT);
	$prepare->bindParam(':trade_status',$data['trade_status'],PDO::PARAM_INT);
	$prepare->bindParam(':seller_id',$data['seller_id']);
	$prepare->bindParam(':pay_type',$data['pay_type'],PDO::PARAM_INT);
	$prepare->bindParam(':create_time',$data['create_time'],PDO::PARAM_INT);
	$prepare->bindParam(':update_time',$data['update_time'],PDO::PARAM_INT);

	$result=$prepare->execute();

	//如果执行失败
	if(!$result){
		Log::ERROR('入库失败,商户订单号:'.$data['out_trade_no']);
	}

}catch(PDOException $e){
	Log::ERROR('数据库异常信息00001'.$e->getMessage());
}

// 业务逻辑-------------------END---------------------------------
$input = new WxPayUnifiedOrder();
$input->SetBody($subject);
$input->SetAttach("test");
$input->SetOut_trade_no($out_trade_no);
$input->SetTotal_fee($total_amount*100);
$input->SetTime_start(date("YmdHis"));
$input->SetTime_expire(date("YmdHis", time() + 600));
$input->SetGoods_tag("");
$input->SetNotify_url("http://youdao.xxkj.com/weixin_trade/example/notify.php");
$input->SetTrade_type("NATIVE");
$input->SetProduct_id("1");
$result = $notify->GetPayUrl($input);
$url2 = $result["code_url"];

//客户端采用第三方二维码生成库
toJson(['errcode'=>0,'errmsg'=>'调用成功','qrcode_url'=>$url2]);
?>