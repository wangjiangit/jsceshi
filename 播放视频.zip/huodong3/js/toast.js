'use strict';
(function($,window){
    //鍔ㄦ€佸姞杞絘nimate
    var loadStyles = function(url) {
        var hasSameStyle = false;
        var links = $('link');
        for(var i = 0;i<links.length;i++){
            if(links.eq(i).attr('href') == url){
                hasSameStyle = true;
                return
            }
        }

        if(!hasSameStyle){
            var link = document.createElement("link");
            link.type = "text/css";
            link.rel = "stylesheet";
            link.href = url;
            document.getElementsByTagName("head")[0].appendChild(link);
        }
    }

    loadStyles('css/animate.css');

    //鏄剧ず鎻愮ず淇℃伅    toast
    $.fn.toast = function(options){
        var $this = $(this);
        var _this = this;
        return this.each(function(){
            $(this).css({
                position:'relative'
            });
            var top = '';		//bottom鐨勪綅缃�
            var translateInfo = ''; 	//灞呬腑鍜屼笉灞呬腑鏃剁殑tarnslate

            var box = '';   //娑堟伅鍏冪礌
            var defaults = {
                position:  			  "absolute", 				//涓嶆槸body鐨勮瘽灏盿bsolute
                animateIn:  		  "fadeIn",					//杩涘叆鐨勫姩鐢�
                animateOut: 		  "fadeOut",				//缁撴潫鐨勫姩鐢�
                padding:              "10px 20px",              //padding
                background:           "rgba(7,17,27,0.66)",     //鑳屾櫙鑹�
                borderRadius:         "6px",                    //鍦嗚
                duration:             3000,                     //瀹氭椂鍣ㄦ椂闂�
                animateDuration: 	  500, 						//鎵ц鍔ㄧ敾鏃堕棿
                fontSize:             14,                   	//瀛椾綋澶у皬
                content:              "杩欐槸涓€涓彁绀轰俊鎭�",       //鎻愮ず鍐呭
                color:                "#fff",                   //鏂囧瓧棰滆壊
                top:            	  "80%",                	//bottom搴曢儴鐨勪綅缃�    鍏蜂綋鐨勬暟鍊� 鎴栬€卌enter  鍨傜洿灞呬腑
                zIndex:               1000001,                	//灞傜骇
                isCenter:   		  true, 					//鏄惁鍨傜洿姘村钩灞呬腑鏄剧ず
                closePrev: 			  true, 					//鍦ㄦ墦寮€涓嬩竴涓猼oast鐨勬椂鍊欑珛鍗冲叧闂笂涓€涓猼oast
            }

            var opt = $.extend(defaults,options||{});
            var t = '';

            // setTimeout(function(){
            //   	box.addClass('show');
            // },10);

            top = opt.isCenter===true? '50%':opt.top;

            defaults.isLowerIe9 = function(){
                return (!window.FormData);
            }

            // translateY(-50%)
            // translateInfo = opt.isCenter===true? 'translate3d(-50%,0,0)':'translate3d(-50%,-50%,0)';

            defaults.createMessage = function(){
                if(opt.closePrev){
                    $('.cpt-toast').remove();
                }
                box = $("<span class='animated "+opt.animateIn+" cpt-toast'></span>").css({
                    "position":opt.position,
                    "padding":opt.padding,
                    "background":opt.background,
                    "font-size":opt.fontSize,
                    "-webkit-border-radius":opt.borderRadius,
                    "-moz-border-radius":opt.borderRadius,
                    "border-radius":opt.borderRadius,
                    "color":opt.color,
                    "top":top,
                    "z-index":opt.zIndex,
                    "-webkit-transform":'translate3d(-50%,-50%,0)',
                    "-moz-transform":'translate3d(-50%,-50%,0)',
                    "transform":'translate3d(-50%,-50%,0)',
                    '-webkit-animation-duration':opt.animateDuration/1000+'s',
                    '-moz-animation-duration':opt.animateDuration/1000+'s',
                    'animation-duration':opt.animateDuration/1000+'s',
                }).html(opt.content).appendTo($this);
                defaults.colseMessage();
            }

            defaults.colseMessage = function(){
                var isLowerIe9 = defaults.isLowerIe9();
                if(!isLowerIe9){
                    t = setTimeout(function(){
                        box.removeClass(opt.animateIn).addClass(opt.animateOut).on('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend',function(){
                            box.remove();
                        });
                    },opt.duration);
                }else{
                    t = setTimeout(function(){
                        box.remove();
                    },opt.duration);
                }
            }

            defaults.createMessage();
        })
    };
})(jQuery,window);


var showMessage = function(content,duration,isCenter,animateIn,animateOut){
    var animateIn = animateIn || 'fadeIn';
    var animateOut = animateOut || 'fadeOut';
    var content = content || '杩欐槸涓€涓彁绀轰俊鎭�';
    var duration = duration || '3000';
    var isCenter = isCenter || false;
    $('body').toast({
        position:'fixed',
        animateIn:animateIn,
        animateOut:animateOut,
        content:content,
        duration:duration,
        isCenter:isCenter,
    });
}