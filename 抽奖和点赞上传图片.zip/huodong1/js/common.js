/*
* 通用的方法
* Write by wxh 
* 2018/1/11
*/
var common = (function () { 
	var DecodeBase64 =function(mi,times){
		var mingwen="";
		var num=1;
		if(typeof times=='undefined'||times==null||times==""){
	    	num=1;
		}else{
		    var vt=times+"";
		    num=parseInt(vt);
		}
		  if(typeof mi=='undefined'||mi==null||mi==""){
		}else{
		    $.base64.utf8encode = true;
		    mingwen=mi;
		    for(var i=0;i<num;i++){
		      mingwen=$.base64.atob(mingwen);
		    }
		}
	  return mingwen;
	}
	var  GetQueryString = function(name){
	    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
	    var r = window.location.search.substr(1).match(reg);
	    if(r!=null)return  decodeURI(r[2]); return null;
	}
	var Getkey = function ()
	{	  
	    return '192c96beaec59d367329c70016e7a50f';
	}
	var GetArgs= function(args) {//解析url?后面的参数传递过来的参数      
	    var Request = new Object();
	    if (args.indexOf("?") != -1) {
	        var str = args.substr(args.indexOf("?") + 1);
	        strs = str.split("&");
	        for (var i = 0; i < strs.length; i++) {
	            Request[strs[i].split("=")[0]] = (strs[i].split("=")[1]);
	        }
	    }
	    return Request;
	}
	return {
        DecodeBase64: DecodeBase64,
        GetQueryString: GetQueryString,
        Getkey: Getkey,
        GetArgs: GetArgs
    };
}
)();
